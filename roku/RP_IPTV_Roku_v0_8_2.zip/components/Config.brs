' Configuração do app (valores públicos). Mesmos valores do app webOS (js/config.js).
' A chave é a publishable do Supabase, feita para uso em apps. Nunca colocar a service_role.

function SupabaseUrl() as String
    return "https://akviutqvsburyjzdjhon.supabase.co"
end function

function SupabaseKey() as String
    return "sb_publishable_j83h2Bh_WuH2l5lq1A7ZeA_raDjOmBQ"
end function

' Página do celular (GitHub Pages). O QR code aponta para ela com ?c=CODIGO.
function PairPageUrl() as String
    return "https://robisonrp.github.io/rp-iptv-pareamento/"
end function

' Serviço público que desenha o QR code como imagem (a TV precisa de internet).
function QrServiceUrl() as String
    return "https://api.qrserver.com/v1/create-qr-code/?size=330x330&margin=8&data="
end function


' Versão deste pacote. Deve ser igual ao manifest (major.minor e build).
function LocalVersion() as String
    return "0.8.2"
end function

' Arquivo de versão publicado no GitHub (pasta roku/ do repositório).
function UpdateVersionUrl() as String
    return "https://robisonrp.github.io/rp-iptv-pareamento/roku/version.json"
end function
