# Limitações conhecidas — RP IPTV v0.6

- **Canais, não catálogo sob demanda.** As listas públicas do IPTV-org são canais ao vivo 24 horas.
  "Filmes" e "Séries" são canais de filmes e séries em transmissão contínua, não biblioteca para escolher o título.
- **Disponibilidade.** Os streams são mantidos pela comunidade. Canais podem sair do ar, mudar de endereço ou exigir cabeçalhos especiais.
- **Globo Curitiba, SBT e outras emissoras.** Só aparecem se estiverem nas listas públicas. O app não inclui links que não possamos verificar como oficiais e gratuitos. Para adicionar um canal, use uma URL M3U legal em **Minhas listas**.
- **Idioma.** A lista "Filmes" e "Séries" reúne canais de vários países; a lista "por" traz canais em português de vários países. Não há filtro de idioma no app.
- **Classificação aproximada.** A seção é deduzida do nome e do grupo do canal. Um canal pode cair na seção errada.
- **Memória.** Listas muito grandes (milhares de canais) podem deixar o app lento ou consumir muita memória no Roku.
- **Teclas.** CH+/CH- e fwd/rev dependem do controle e podem não ser repassados ao app. As setas ↑ ↓ funcionam em todos os modelos.
- **Guia EPG.** Não está disponível nesta versão. O componente `EpgTask` existe mas não é usado.
- **Teste em aparelho.** A interface foi validada apenas por análise de sintaxe e de estrutura. Valide com `tests/README.md`.
- **Fontes de URL.** Os endereços das categorias e do idioma seguem a estrutura pública do IPTV-org. Se algum estiver fora do ar, o app mostra o erro e segue com as demais listas.

- **Pareamento (Roku):** o QR code é desenhado por um serviço público (`api.qrserver.com`), então a TV precisa de internet para mostrar o QR. Sem ele, o código de 6 letras continua funcionando na página.
- **Teste em aparelho:** o pareamento, as seções e o menu dinâmico foram validados por testes unitários de lógica e checagem de sintaxe. A interface SceneGraph ainda precisa ser confirmada na TV.
