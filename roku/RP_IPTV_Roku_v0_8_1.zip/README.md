# RP IPTV Roku — v0.6 (build 00006)

Aplicativo de canais M3U gratuitos e públicos para Roku.

## Seções (menu à esquerda)
- **Canais abertos**: canais de TV aberta e generalistas do Brasil.
- **Filmes**, **Séries**, **Infantil**: canais ao vivo dessas categorias.
- **Todos os canais**: todas as listas ativas juntas.
- **Minhas listas**: liga/desliga cada lista e adiciona novas.
- **Favoritos**, **Histórico** (últimos 25), **Buscar**.

## Controles (controle Roku padrão)
- ↑ ↓ navegam no menu ou na lista. → entra na lista. ← volta ao menu.
- **OK**: abre a seção ou reproduz o canal em tela cheia.
- **PLAY**: reproduz o canal focado.
- **REPLAY**: favorita o canal (nas seções de canais) ou remove a lista (em Minhas listas).
- **\*** (OPTIONS): em Minhas listas, adiciona uma nova lista por URL.
- **BACK**: volta; no menu, pede confirmação para sair.

### Em tela cheia
- Mostra a miniatura (logo) e o nome do canal por 5 segundos. **INFO** mostra de novo.
- **↑ / CH+** e **fwd**: próximo canal. **↓ / CH-** e **rev**: canal anterior.
  (CH+/CH- dependem do controle e podem não ser repassados ao app em todos os modelos.)
- **OK**: abre a lista de canais ao lado. **OK** em um canal da lista troca para ele.
- **BACK**: fecha a lista; sem lista aberta, volta à navegação.

## Listas padrão (IPTV-org, comunidade pública)
1. TV aberta e canais do Brasil — `countries/br.m3u`
2. Filmes — `categories/movies.m3u`
3. Séries — `categories/series.m3u`
4. Infantil — `categories/kids.m3u`
5. Canais em português, todos os países — `languages/por.m3u`

Todas podem ser desligadas em **Minhas listas**. Você pode adicionar outras listas M3U
(http/https) que tenha autorização para usar.

## Como as seções são definidas
Cada canal é classificado pelo nome e pelo grupo do M3U (ex.: "Gloob", "Cartoon" → Infantil;
"Movies", "Telecine" → Filmes; "Series", "Novela" → Séries). Se nada indicar a seção, usa a
seção padrão da lista de origem; sem isso, fica em "Canais abertos".

## Instalação (sideload)
Developer Application Installer. O `manifest` deve estar na raiz do ZIP.

## Histórico de versões
### v0.6.2 (build 00008)
- Corrigido: BACK e ← na lista não voltavam ao menu. O menu agora é uma lista focável, então o foco passa de verdade entre menu e lista.
- Corrigido: a confirmação "Sair" não fechava o app. A tela agora sinaliza ao `main.brs`, que encerra o app.
### v0.6.1 (build 00007)
- BACK no menu pede confirmação ("Sair do RP IPTV?") antes de fechar o app.
- Em tela cheia, ↑ ↓ e CH+/CH- trocam de canal (o foco agora fica no player, e não mais na lista oculta).
- A lista lateral (OK) abre posicionada no canal que está tocando, e ao sair da reprodução a lista volta ao mesmo canal.
### v0.6 (build 00006)
- Seções: Canais abertos, Filmes, Séries, Infantil (menu à esquerda).
- Reprodução em tela cheia, com miniatura e nome do canal; troca com CH+/CH- ou ↑ ↓; lista lateral com OK.
- Minhas listas: item "+ Adicionar nova lista" visível, liga/desliga e remoção.
- Catálogo combinado de todas as listas ativas, com carregamento em fila e tempo limite de 60 s por lista.
- Listas padrão adicionadas automaticamente em instalações existentes (sem remover as suas).
- Menu "Guia EPG" removido, pois o guia ainda não está implementado.
- Classificação de canais por nome e grupo (testada em `tests/unit`).

### v0.5 (build 00005)
- Corrigido: `SetRequest` com dois argumentos travava o download. Agora usa `AddHeader`.
