' Funções puras de parsing (M3U e XMLTV).
' Não usam SceneGraph, para que possam ser testadas isoladamente em tests/unit.

function IsHttpUrl(value as String) as Boolean
    lower = LCase(value)
    return Left(lower, 7) = "http://" or Left(lower, 8) = "https://"
end function

function ExtractAttribute(line as String, key as String) as String
    needle = key + "=" + Chr(34)
    startAt = Instr(1, line, needle)
    if startAt = 0 then return ""
    startAt = startAt + Len(needle)
    endAt = Instr(startAt, line, Chr(34))
    if endAt = 0 then return ""
    return Mid(line, startAt, endAt - startAt)
end function

' Nome do canal em uma linha #EXTINF: texto após a vírgula que vem depois
' do último atributo entre aspas (o nome pode conter vírgulas nos atributos).
function ExtractExtinfName(line as String) as String
    lastQuote = 0
    p = Instr(1, line, Chr(34))
    while p > 0
        lastQuote = p
        p = Instr(p + 1, line, Chr(34))
    end while
    fromPos = 1
    if lastQuote > 0 then fromPos = lastQuote + 1
    comma = Instr(fromPos, line, ",")
    if comma = 0 then return "Canal"
    name = Mid(line, comma + 1).Trim()
    if name = "" then return "Canal"
    return name
end function

function ParsePlaylistText(text as String) as Object
    channels = []
    lines = text.Replace(Chr(13), "").Split(Chr(10))
    pendingName = ""
    pendingCategory = ""
    pendingLogo = ""
    pendingId = ""
    for each rawLine in lines
        line = rawLine.Trim()
        if line <> ""
            if Left(line, 7) = "#EXTINF"
                pendingName = ExtractExtinfName(line)
                pendingCategory = ExtractAttribute(line, "group-title")
                pendingLogo = ExtractAttribute(line, "tvg-logo")
                pendingId = ExtractAttribute(line, "tvg-id")
            else if Left(line, 1) <> "#" and IsHttpUrl(line)
                name = pendingName
                if name = "" then name = line
                channels.Push({name: name, url: line, category: pendingCategory, logo: pendingLogo, epgId: pendingId})
                pendingName = ""
                pendingCategory = ""
                pendingLogo = ""
                pendingId = ""
            end if
        end if
    end for
    return channels
end function

function GuessStreamFormat(url as String) as String
    lower = LCase(url)
    if Instr(1, lower, ".mp4") > 0 then return "mp4"
    if Instr(1, lower, ".mp3") > 0 then return "mp3"
    if Right(lower, 3) = ".ts" then return "ts"
    return "hls"
end function

function GetXmlAttribute(block as String, key as String) as String
    needle = key + "=" + Chr(34)
    p = Instr(1, block, needle)
    if p = 0 then return ""
    p = p + Len(needle)
    q = Instr(p, block, Chr(34))
    if q = 0 then return ""
    return Mid(block, p, q - p)
end function

function GetXmlTag(block as String, tag as String) as String
    openTag = "<" + tag
    p = Instr(1, block, openTag)
    if p = 0 then return ""
    p = Instr(p, block, ">")
    if p = 0 then return ""
    p = p + 1
    closeTag = "</" + tag + ">"
    q = Instr(p, block, closeTag)
    if q = 0 then return ""
    return Mid(block, p, q - p)
end function

' Decodifica entidades. &amp; por último, para não gerar entidades duplas.
function DecodeXml(value as String) as String
    result = value.Replace("&lt;", "<")
    result = result.Replace("&gt;", ">")
    result = result.Replace("&quot;", Chr(34))
    result = result.Replace("&apos;", "'")
    result = result.Replace("&amp;", "&")
    return result.Trim()
end function

' Offset em segundos de um timestamp XMLTV ("AAAAMMDDHHMMSS +HHMM").
' Local = UTC + offset, portanto UTC = local - offset.
function XmltvOffsetSeconds(value as String) as Integer
    if Len(value) < 20 then return 0
    sign = Mid(value, 16, 1)
    if sign <> "+" and sign <> "-" then return 0
    hh = Int(Val(Mid(value, 17, 2)))
    mm = Int(Val(Mid(value, 19, 2)))
    total = hh * 3600 + mm * 60
    if sign = "-" then total = -total
    return total
end function

function XmltvTimeToSeconds(value as String) as Dynamic
    if Len(value) < 14 then return 0
    iso = Left(value, 4) + "-" + Mid(value, 5, 2) + "-" + Mid(value, 7, 2) + "T" + Mid(value, 9, 2) + ":" + Mid(value, 11, 2) + ":" + Mid(value, 13, 2) + "Z"
    dt = CreateObject("roDateTime")
    dt.FromISO8601String(iso)
    return dt.AsSeconds() - XmltvOffsetSeconds(value)
end function

function ParseXmltvText(xmlText as String) as Object
    results = []
    blocks = xmlText.Split("<programme")
    for i = 1 to blocks.Count() - 1
        block = blocks[i]
        channelId = GetXmlAttribute(block, "channel")
        startSec = XmltvTimeToSeconds(GetXmlAttribute(block, "start"))
        stopSec = XmltvTimeToSeconds(GetXmlAttribute(block, "stop"))
        title = DecodeXml(GetXmlTag(block, "title"))
        if title <> "" and channelId <> "" and startSec > 0 and stopSec > startSec
            results.Push({channelId: channelId, start: startSec, stop: stopSec, title: title})
        end if
        if results.Count() >= 2000 then exit for
    end for
    return results
end function

' Verdadeiro se "texto" contém qualquer uma das palavras da lista.
function ContainsAny(texto as String, palavras as Object) as Boolean
    for each p in palavras
        if Instr(1, texto, p) > 0 then return true
    end for
    return false
end function

' Seções do menu, na ordem de exibição (mesma ordem do app webOS).
function SectionOrder() as Object
    return ["Canais abertos", "Filmes", "Séries", "Desenhos e infantil", "Futebol e esportes", "Notícias", "Música", "Documentários e educação", "Religiosos", "Culinária", "Outros"]
end function

' group-title do M3U (inglês ou português) -> seção do app.
function GroupMap() as Object
    return [
        {words: ["movie", "film", "cinema"], label: "Filmes"},
        {words: ["series", "série", "tv show", "sitcom", "novela"], label: "Séries"},
        {words: ["kids", "infantil", "children", "cartoon", "animation", "animação", "desenho"], label: "Desenhos e infantil"},
        {words: ["sport", "esporte", "futebol", "football", "soccer"], label: "Futebol e esportes"},
        {words: ["news", "notícia", "noticia"], label: "Notícias"},
        {words: ["music", "música", "musica"], label: "Música"},
        {words: ["documentary", "documentário", "documentario", "education", "educação", "educacao", "science", "culture", "cultura"], label: "Documentários e educação"},
        {words: ["religio"], label: "Religiosos"},
        {words: ["cooking", "culinária", "culinaria", "food"], label: "Culinária"},
        {words: ["general", "entertainment", "abertos", "aberto", "generalista", "public"], label: "Canais abertos"}
    ]
end function

' Seção pelo grupo do M3U. Vazio se o grupo não for reconhecido.
function NormalizeGroup(grupo as String) as String
    g = LCase(grupo.Trim())
    if g = "" then return ""
    for each entrada in GroupMap()
        if ContainsAny(g, entrada.words) then return entrada.label
    end for
    return ""
end function

' Seção do canal: primeiro pelo grupo; se for genérico ou ausente, pelo nome.
function SectionFor(name as String, grupo as String) as String
    g = NormalizeGroup(grupo)
    if g <> "" and g <> "Canais abertos" then return g
    n = LCase(name)
    if ContainsAny(n, ["kids", "gloob", "cartoon", "cartoonito", "nick", "junior", "boomerang", "discovery kids", "ra-tim-bum", "rá-tim-bum", "desenho", "tiny"]) then return "Desenhos e infantil"
    if ContainsAny(n, ["sport", "sports", "esporte", "futebol", "espn", "premiere", "combate", "libertadores", "copa", "fox sports", "band sports", "cazé", "cazetv"]) then return "Futebol e esportes"
    if ContainsAny(n, ["movie", "movies", "filme", "cinema", "cine ", "telecine", "paramount", "tcm", "megapix"]) then return "Filmes"
    if ContainsAny(n, ["series", "séries", "serie ", "sitcom", "novela"]) then return "Séries"
    if ContainsAny(n, ["news", "notícia", "noticia", "cnn", "globonews", "record news", "band news", "jornal"]) then return "Notícias"
    if g <> "" then return "Canais abertos"
    if grupo.Trim() <> "" then return "Outros"
    return "Canais abertos"
end function

' Código de pareamento: 6 caracteres sem I, O, 0, 1 (igual ao app webOS e ao banco).
function PairAlphabet() as String
    return "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
end function

' indices: array de 6 inteiros entre 0 e 31. Produção: Rnd(32) - 1.
function MakePairCode(indices as Object) as String
    alfabeto = PairAlphabet()
    out = ""
    for each i in indices
        out = out + Mid(alfabeto, i + 1, 1)
    end for
    return out
end function

function RandomPairCode() as String
    indices = []
    for n = 1 to 6
        indices.Push(Rnd(32) - 1)
    end for
    return MakePairCode(indices)
end function

function IsPairCode(codigo as String) as Boolean
    if Len(codigo) <> 6 then return false
    alfabeto = PairAlphabet()
    for n = 1 to 6
        if Instr(1, alfabeto, Mid(codigo, n, 1)) = 0 then return false
    end for
    return true
end function

' Compara "a.b.c" com "b.c.d" de forma numérica (0.10.0 > 0.9.0). >0 se a > b, <0 se a < b, 0 se iguais.
function CompareVersion(a as String, b as String) as Integer
    x = a.Trim().Split(".")
    y = b.Trim().Split(".")
    n = x.Count()
    if y.Count() > n then n = y.Count()
    for i = 0 to n - 1
        va = 0
        vb = 0
        if i < x.Count() then va = Int(Val(x[i]))
        if i < y.Count() then vb = Int(Val(y[i]))
        if va <> vb then return va - vb
    end for
    return 0
end function
