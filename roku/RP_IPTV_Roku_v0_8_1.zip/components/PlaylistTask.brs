sub init()
    m.top.functionName = "Run"
end sub

sub Run()
    DownloadAndParse()
end sub

sub DownloadAndParse()
    url = m.top.url
    if url = invalid or url = ""
        m.top.error = "URL vazia"
        return
    end if
    m.top.progress = "Conectando ao servidor..."
    xfer = CreateObject("roUrlTransfer")
    xfer.SetUrl(url)
    xfer.AddHeader("User-Agent", "RP-IPTV-Roku/0.5")
    xfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.InitClientCertificates()
    response = xfer.GetToString()
    if response = invalid or response = ""
        m.top.error = "Download vazio ou falhou (sem resposta do servidor)"
        return
    end if
    m.top.progress = "Recebidos " + Len(response).ToStr() + " bytes. Interpretando..."
    channels = ParsePlaylistText(response)
    if channels.Count() = 0
        m.top.error = "Nenhum canal HTTP(S) encontrado no arquivo recebido"
        return
    end if
    m.top.progress = channels.Count().ToStr() + " canais encontrados."
    m.top.result = channels
end sub
