' Baixa o arquivo de versão do GitHub em segundo plano.
' O código de resultado é 200 quando veio um JSON válido, e 0 em qualquer outro caso.
' (GetResponseCode() não é válido para roUrlTransfer síncrono: causava travamento.)
' codigoHttp é definido por último, porque é ele que dispara o observador na tela.

sub init()
    m.top.functionName = "Run"
end sub

sub Run()
    xfer = CreateObject("roUrlTransfer")
    xfer.SetUrl(m.top.url)
    xfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.InitClientCertificates()
    texto = xfer.GetToString()
    if texto = invalid then texto = ""
    texto = texto.Trim()
    m.top.resposta = texto
    codigo = 0
    if Left(texto, 1) = "{" then codigo = 200
    m.top.codigoHttp = codigo
end sub
