' ---------------------------------------------------------------------------
' RP IPTV — tela principal
' Modos: "browse" (navegação com menu e lista) e "play" (tela cheia).
' Catálogo: união das listas ativas, cada canal recebe uma seção
' (Canais abertos, Filmes, Séries, Desenhos e infantil, Futebol...) via SectionFor.
' O menu de seções é montado a partir do catálogo (BuildMenu).
' ---------------------------------------------------------------------------

sub init()
    m.browseGroup = m.top.findNode("browseGroup")
    m.playGroup = m.top.findNode("playGroup")
    m.player = m.top.findNode("player")
    m.overlayBg = m.top.findNode("overlayBg")
    m.bannerGroup = m.top.findNode("bannerGroup")
    m.bannerName = m.top.findNode("bannerName")
    m.bannerInfo = m.top.findNode("bannerInfo")
    m.bannerLogo = m.top.findNode("bannerLogo")
    m.channelList = m.top.findNode("channelList")
    m.status = m.top.findNode("status")
    m.sectionTitle = m.top.findNode("sectionTitle")
    m.loadTimer = m.top.findNode("loadTimer")
    m.bannerTimer = m.top.findNode("bannerTimer")

    m.menuItems = []
    m.pairState = ""
    m.pairCode = ""
    m.pairStart = 0
    m.pairBusy = false
    m.pairTask = invalid
    m.pairGroup = m.top.findNode("pairGroup")
    m.pairQr = m.top.findNode("pairQr")
    m.pairCodeText = m.top.findNode("pairCodeText")
    m.pairInfo = m.top.findNode("pairInfo")
    m.pairStatus = m.top.findNode("pairStatus")
    m.pairTimer = m.top.findNode("pairTimer")
    m.pairTimer.observeField("fire", "onPairTimer")

    m.mode = "browse"
    m.overlayOpen = false
    m.focusArea = "menu"
    m.currentView = "category"
    m.currentCat = "Canais abertos"
    m.listKind = "channels"
    m.channels = []
    m.visibleChannels = []
    m.viewSource = []
    m.listSource = []
    m.playSource = []
    m.playIndex = 0
    m.favorites = []
    m.history = []
    m.lists = []
    m.cache = {}
    m.queue = []
    m.loading = false
    m.currentUrl = ""
    m.loadTotal = 0
    m.loadDone = 0
    m.loadErrors = 0
    m.playlistTask = invalid
    m.searchDialog = invalid
    m.addListDialog = invalid
    m.exitDialog = invalid
    m.playContext = ""
    m.updateMsg = ""
    m.updateRemote = invalid
    m.updateChecking = false
    m.updateSilent = false
    m.updateTask = invalid
    m.infoDialog = invalid

    m.player.observeField("state", "onPlayerState")
    m.loadTimer.observeField("fire", "onLoadTimeout")
    m.bannerTimer.observeField("fire", "onBannerTimeout")

    LoadSavedData()
    MigrateLists()
    m.menuList = m.top.findNode("menuList")
    BuildMenu()
    m.menuList.setFocus(true)
    UpdateView()
    RefreshCatalog()
    m.top.findNode("brand").text = "RP IPTV  v" + LocalVersion()
    if AutoCheckOn() then CheckUpdate(true)
end sub

' ------------------------------------------------------------------ teclas ---

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false
    k = LCase(key)
    if m.pairState <> "" then
        if k = "back" then CancelPairing()
        return true
    end if
    if m.mode = "play" then return HandlePlayKey(k)
    return HandleBrowseKey(k)
end function

function HandleBrowseKey(k as String) as Boolean
    if k = "back"
        if m.focusArea = "list"
            FocusMenu()
            return true
        end if
        ShowExitDialog()
        return true
    else if k = "right"
        if m.focusArea = "menu"
            FocusList()
            return true
        end if
    else if k = "left"
        if m.focusArea = "list"
            FocusMenu()
            return true
        end if
    else if k = "ok" or k = "select"
        if m.focusArea = "menu"
            ActivateMenu(m.menuList.itemFocused)
        else
            SelectFocused()
        end if
        return true
    else if k = "options"
        if m.listKind = "lists"
            ShowAddListDialog()
        else
            m.status.text = "OK reproduz  •  REPLAY favorita  •  BACK volta"
        end if
        return true
    else if k = "replay" or k = "instantreplay"
        if m.listKind = "lists"
            RemoveFocusedList()
        else
            ToggleFavoriteFocused()
        end if
        return true
    else if k = "play"
        if m.focusArea = "list" then PlayFocused()
        return true
    end if
    return false
end function

function HandlePlayKey(k as String) as Boolean
    if k = "back"
        if m.overlayOpen
            CloseOverlay()
        else
            StopPlayback()
        end if
        return true
    end if
    if m.overlayOpen
        if k = "ok" or k = "select"
            SelectFocused()
            return true
        end if
        return false ' Setas são tratadas pela lista lateral.
    end if
    if k = "ok" or k = "select"
        OpenOverlay()
        return true
    end if
    if k = "up" or k = "channelup" or k = "fwd"
        ChannelStep(1)
        return true
    end if
    if k = "down" or k = "channeldown" or k = "rev"
        ChannelStep(-1)
        return true
    end if
    if k = "info"
        ShowCurrentBanner()
        return true
    end if
    return false
end function

' ---------------------------------------------------------------- navegação ---

sub FocusMenu()
    m.focusArea = "menu"
    m.menuList.setFocus(true)
end sub

sub FocusList()
    m.focusArea = "list"
    m.channelList.setFocus(true)
end sub


' Monta o menu: seções que existem no catálogo (com contagem) e os itens fixos.
sub BuildMenu()
    contagem = {}
    for each ch in m.channels
        if contagem.DoesExist(ch.cat)
            contagem[ch.cat] = contagem[ch.cat] + 1
        else
            contagem[ch.cat] = 1
        end if
    end for

    m.menuItems = []
    for each nome in SectionOrder()
        if contagem.DoesExist(nome)
            m.menuItems.Push({label: nome + "  (" + contagem[nome].ToStr() + ")", view: "category", cat: nome, title: nome})
        end if
    end for
    m.menuItems.Push({label: "Todos os canais", view: "channels", cat: "", title: "Todos os canais"})
    m.menuItems.Push({label: "Minhas listas", view: "lists", cat: "", title: "Minhas listas"})
    m.menuItems.Push({label: "Favoritos", view: "favorites", cat: "", title: "Favoritos"})
    m.menuItems.Push({label: "Histórico", view: "history", cat: "", title: "Histórico"})
    m.menuItems.Push({label: "Atualização", view: "update", cat: "", title: "Atualização"})
    m.menuItems.Push({label: "Buscar", view: "search", cat: "", title: "Buscar"})

    rows = CreateObject("roSGNode", "ContentNode")
    for each item in m.menuItems
        r = rows.createChild("ContentNode")
        r.title = item.label
    end for
    m.menuList.content = rows

    ' Se a seção aberta deixou de existir (ex.: lista removida), volta para a primeira disponível.
    if m.currentView = "category" and not contagem.DoesExist(m.currentCat)
        if m.menuItems.Count() > 0
            m.currentCat = m.menuItems[0].cat
            m.sectionTitle.text = m.menuItems[0].title
        end if
    end if
end sub

sub ActivateMenu(idx as Integer)
    if idx < 0 or idx >= m.menuItems.Count() then return
    item = m.menuItems[idx]
    if item.view = "search"
        ShowSearchDialog()
        return
    end if
    m.currentView = item.view
    m.currentCat = item.cat
    m.sectionTitle.text = item.title
    ' Em "Minhas listas" o foco vai para a lista, como no app webOS.
    if item.view = "lists" or item.view = "update" then m.focusArea = "list"
    UpdateView()
end sub

' Preenche a lista com o conteúdo da seção atual.
sub UpdateView()
    if m.mode = "play" then return
    if m.currentView = "update"
        RenderUpdateList()
        return
    end if
    if m.currentView = "lists"
        m.listKind = "lists"
        m.viewSource = m.lists
        rows = CreateObject("roSGNode", "ContentNode")
        pairRow = rows.createChild("ContentNode")
        pairRow.title = "+ Adicionar pelo celular (QR code)"
        manualRow = rows.createChild("ContentNode")
        manualRow.title = "Digitar a URL no controle"
        for each lst in m.lists
            item = rows.createChild("ContentNode")
            item.title = ListRowTitle(lst)
        end for
    else
        m.listKind = "channels"
        m.viewSource = CurrentSource()
        rows = BuildRows(m.viewSource)
    end if
    m.listSource = m.viewSource
    m.channelList.content = rows
    m.channelList.visible = true
    if m.focusArea = "list"
        m.channelList.setFocus(true)
    else
        m.menuList.setFocus(true)
    end if
    m.status.text = StatusFor()
end sub

function CurrentSource() as Object
    if m.currentView = "favorites" then return m.favorites
    if m.currentView = "history" then return m.history
    if m.currentView = "search" then return m.visibleChannels
    if m.currentView = "category" then return FilterCategory(m.channels, m.currentCat)
    return m.channels
end function

function FilterCategory(lista as Object, cat as String) as Object
    result = []
    for each ch in lista
        if ch.cat = cat then result.Push(ch)
    end for
    return result
end function

function BuildRows(source as Object) as Object
    rows = CreateObject("roSGNode", "ContentNode")
    for each ch in source
        item = rows.createChild("ContentNode")
        label = ch.name
        if ch.cat <> invalid and ch.cat <> "" then label = ch.cat + "  |  " + ch.name
        item.title = label
    end for
    return rows
end function

function StatusFor() as String
    if m.currentView = "update" then return m.updateMsg
    if m.currentView = "lists"
        if m.lists.Count() = 0
            return "Nenhuma lista cadastrada. Use a primeira opção (celular) ou a segunda (digitar)."
        end if
        return m.lists.Count().ToStr() + " listas  •  OK liga/desliga  •  REPLAY remove"
    end if
    n = m.viewSource.Count()
    if n = 0 then return "Nenhum canal nesta seção ainda. Aguarde o carregamento ou ative uma lista."
    return n.ToStr() + " canais. Use ↑ ↓ e OK."
end function

sub SelectFocused()
    idx = m.channelList.itemFocused
    if idx < 0 then return
    if m.mode = "play"
        PlayChannel(m.playSource, idx)
        return
    end if
    if m.listKind = "update"
        RunUpdateItem(idx)
        return
    end if
    if m.listKind = "lists"
        if idx = 0
            StartPairing()
        else if idx = 1
            ShowAddListDialog()
        else
            ToggleListActive(idx - 2)
        end if
        return
    end if
    if m.focusArea = "list" then PlayChannel(m.viewSource, idx)
end sub

sub PlayFocused()
    if m.listKind = "lists" or m.listKind = "update" then return
    idx = m.channelList.itemFocused
    if idx < 0 then return
    PlayChannel(m.viewSource, idx)
end sub

' -------------------------------------------------------------- reprodução ---

sub PlayChannel(source as Object, idx as Integer)
    if source = invalid or idx < 0 or idx >= source.Count() then return
    ch = source[idx]
    if ch.url = invalid or ch.url = "" then return
    m.playSource = source
    m.playIndex = idx
    m.playContext = m.currentView + "|" + m.currentCat
    AddHistory(ch)
    EnterPlayMode()
    content = CreateObject("roSGNode", "ContentNode")
    content.url = ch.url
    content.title = ch.name
    content.streamFormat = GuessStreamFormat(ch.url)
    m.player.control = "stop"
    m.player.content = content
    m.player.control = "play"
    ShowBanner(ch)
end sub

sub EnterPlayMode()
    m.mode = "play"
    m.overlayOpen = false
    m.overlayBg.visible = false
    m.channelList.visible = false
    m.browseGroup.visible = false
    m.playGroup.visible = true
    m.player.visible = true
    m.player.setFocus(true)
end sub

sub StopPlayback()
    m.player.control = "stop"
    m.player.visible = false
    m.playGroup.visible = false
    m.bannerGroup.visible = false
    m.bannerTimer.control = "stop"
    m.mode = "browse"
    m.browseGroup.visible = true
    m.overlayOpen = false
    SetBrowseLayout()
    m.focusArea = "list"
    UpdateView()
    if m.playContext = m.currentView + "|" + m.currentCat
        JumpListTo(m.playIndex)
    end if
    m.channelList.setFocus(true)
    m.status.text = "Reprodução encerrada.  " + m.status.text
end sub

sub ChannelStep(delta as Integer)
    n = m.playSource.Count()
    if n = 0 then return
    nextIdx = (m.playIndex + delta + n) mod n
    PlayChannel(m.playSource, nextIdx)
end sub

sub OpenOverlay()
    m.overlayOpen = true
    m.bannerGroup.visible = false
    m.bannerTimer.control = "stop"
    m.overlayBg.visible = true
    SetOverlayLayout()
    m.listKind = "channels"
    m.listSource = m.playSource
    m.channelList.content = BuildRows(m.playSource)
    m.channelList.visible = true
    JumpListTo(m.playIndex)
    m.channelList.setFocus(true)
end sub

' Posiciona o foco da lista em um índice (se existir).
sub JumpListTo(idx as Integer)
    if idx >= 0 and idx < m.listSource.Count()
        m.channelList.jumpToItem = idx
    end if
end sub

sub CloseOverlay()
    m.overlayOpen = false
    m.overlayBg.visible = false
    m.channelList.visible = false
    m.player.setFocus(true)
end sub

sub SetBrowseLayout()
    m.channelList.translation = [342, 226]
    m.channelList.itemSize = [870, 46]
    m.channelList.numRows = 8
end sub

sub SetOverlayLayout()
    m.channelList.translation = [830, 40]
    m.channelList.itemSize = [430, 46]
    m.channelList.numRows = 12
end sub

sub ShowCurrentBanner()
    if m.playSource.Count() > m.playIndex then ShowBanner(m.playSource[m.playIndex])
end sub

sub ShowBanner(ch as Object)
    if m.overlayOpen then return
    m.bannerName.text = ch.name
    cat = ""
    if ch.cat <> invalid then cat = ch.cat
    m.bannerInfo.text = cat + "     ↑ ↓ ou CH+/CH- trocam o canal     OK: lista     BACK: sair"
    logo = ""
    if ch.logo <> invalid then logo = ch.logo
    if logo <> "" and IsHttpUrl(logo)
        m.bannerLogo.uri = logo
        m.bannerLogo.visible = true
    else
        m.bannerLogo.visible = false
    end if
    m.bannerGroup.visible = true
    m.bannerTimer.control = "stop"
    m.bannerTimer.control = "start"
end sub

sub onBannerTimeout()
    m.bannerGroup.visible = false
end sub

sub onPlayerState()
    if m.player.state = "error"
        m.bannerName.text = "Não foi possível reproduzir este canal"
        m.bannerInfo.text = "Pressione ↑ ou CH+ para o próximo canal, ou BACK para sair"
        m.bannerLogo.visible = false
        m.bannerGroup.visible = true
        m.bannerTimer.control = "stop"
    end if
end sub

' --------------------------------------------------------------- catálogo ---

' Listas que versões anteriores pré-configuravam. Removidas uma vez (seedVersion 3).
function OldDefaultUrls() as Object
    return [
        "https://iptv-org.github.io/iptv/countries/br.m3u",
        "https://iptv-org.github.io/iptv/categories/movies.m3u",
        "https://iptv-org.github.io/iptv/categories/series.m3u",
        "https://iptv-org.github.io/iptv/categories/kids.m3u",
        "https://iptv-org.github.io/iptv/languages/por.m3u"
    ]
end function

function ContainsUrl(urls as Object, url as String) as Boolean
    for each u in urls
        if u = url then return true
    end for
    return false
end function

function HasListUrl(lista as Object, url as String) as Boolean
    for each lst in lista
        if lst.url = url then return true
    end for
    return false
end function

' O app começa limpo. Remove só as listas pré-configuradas antigas; as do usuário ficam.
sub MigrateLists()
    if LoadAny("seedVersion", 0) < 3
        mantidas = []
        for each lst in m.lists
            if not ContainsUrl(OldDefaultUrls(), lst.url) then mantidas.Push(lst)
        end for
        m.lists = mantidas
        SaveLists()
        SaveData("seedVersion", 3)
    end if
end sub

function ListRowTitle(lst as Object) as String
    marca = "[LIGADA]  "
    if lst.active = false then marca = "[DESLIGADA]  "
    total = ""
    if m.cache.DoesExist(lst.url) then total = "   (" + m.cache[lst.url].Count().ToStr() + " canais)"
    return marca + lst.name + total
end function

sub ToggleListActive(i as Integer)
    if i < 0 or i >= m.lists.Count() then return
    lst = m.lists[i]
    if lst.active = false
        lst.active = true
    else
        lst.active = false
    end if
    SaveLists()
    RefreshCatalog()
    UpdateView()
end sub

' Baixa, em fila, as listas ativas que ainda não estão em cache ou falharam antes.
' Se já há um download em andamento, apenas acrescenta as listas novas à fila,
' sem iniciar uma segunda tarefa em paralelo.
sub RefreshCatalog()
    if m.loading
        for each lst in m.lists
            if lst.active <> false and NeedsLoad(lst.url) and not HasInQueue(lst.url) and lst.url <> m.currentUrl
                m.queue.Push(lst.url)
                m.loadTotal = m.loadTotal + 1
            end if
        end for
        return
    end if
    m.queue = []
    for each lst in m.lists
        if lst.active <> false and NeedsLoad(lst.url)
            m.queue.Push(lst.url)
        end if
    end for
    m.loadTotal = m.queue.Count()
    m.loadDone = 0
    m.loadErrors = 0
    StartNextLoad()
end sub

function NeedsLoad(url as String) as Boolean
    if not m.cache.DoesExist(url) then return true
    return m.cache[url].Count() = 0
end function

function HasInQueue(url as String) as Boolean
    for each u in m.queue
        if u = url then return true
    end for
    return false
end function

sub StartNextLoad()
    if m.queue.Count() = 0
        m.loading = false
        m.loadTimer.control = "stop"
        BuildCatalog()
        UpdateView()
        m.status.text = CatalogSummary()
        return
    end if
    m.currentUrl = m.queue[0]
    m.queue.Delete(0)
    m.loading = true
    m.status.text = "Carregando lista " + (m.loadDone + 1).ToStr() + " de " + m.loadTotal.ToStr() + "..."
    task = CreateObject("roSGNode", "PlaylistTask")
    task.url = m.currentUrl
    task.observeField("result", "onPlaylistResult")
    task.observeField("error", "onPlaylistError")
    task.observeField("progress", "onPlaylistProgress")
    m.playlistTask = task
    m.top.appendChild(task)
    m.loadTimer.control = "stop"
    m.loadTimer.control = "start"
    task.control = "RUN"
end sub

sub onPlaylistProgress()
    if m.loading and m.mode = "browse" and m.playlistTask <> invalid
        m.status.text = "Lista " + (m.loadDone + 1).ToStr() + " de " + m.loadTotal.ToStr() + ": " + m.playlistTask.progress
    end if
end sub

sub onPlaylistResult()
    if m.playlistTask = invalid then return
    result = m.playlistTask.result
    if result = invalid then return
    m.cache[m.currentUrl] = result
    m.loadDone = m.loadDone + 1
    StartNextLoad()
end sub

sub onPlaylistError()
    if m.playlistTask = invalid then return
    m.cache[m.currentUrl] = []
    m.loadDone = m.loadDone + 1
    m.loadErrors = m.loadErrors + 1
    StartNextLoad()
end sub

sub onLoadTimeout()
    if not m.loading then return
    if m.playlistTask <> invalid
        ' Desliga os observadores: se a tarefa responder depois, a resposta é ignorada.
        m.playlistTask.unobserveField("result")
        m.playlistTask.unobserveField("error")
        m.playlistTask.unobserveField("progress")
        m.playlistTask.control = "STOP"
    end if
    m.cache[m.currentUrl] = []
    m.loadDone = m.loadDone + 1
    m.loadErrors = m.loadErrors + 1
    StartNextLoad()
end sub

' Monta m.channels com a união das listas ativas (sem duplicar URLs).
sub BuildCatalog()
    seen = {}
    merged = []
    for each lst in m.lists
        if lst.active <> false
            if m.cache.DoesExist(lst.url)
                for each ch in m.cache[lst.url]
                    if not seen.DoesExist(ch.url)
                        seen[ch.url] = true
                        ch.cat = SectionFor(ch.name, ch.category)
                        merged.Push(ch)
                    end if
                end for
            end if
        end if
    end for
    m.channels = merged
    BuildMenu()
end sub

function CatalogSummary() as String
    ativas = 0
    for each lst in m.lists
        if lst.active <> false then ativas = ativas + 1
    end for
    msg = m.channels.Count().ToStr() + " canais de " + ativas.ToStr() + " listas ativas."
    if m.loadErrors > 0
        msg = msg + "  " + m.loadErrors.ToStr() + " lista(s) falharam: verifique a rede ou remova em Minhas listas."
    end if
    return msg
end function

' ------------------------------------------------------------------ sair ---

sub ShowExitDialog()
    if m.exitDialog <> invalid then return
    dialog = CreateObject("roSGNode", "StandardMessageDialog")
    dialog.title = "Sair do RP IPTV?"
    dialog.message = ["Deseja realmente fechar o aplicativo?"]
    dialog.buttons = ["Sair", "Cancelar"]
    dialog.observeField("buttonSelected", "onExitButton")
    dialog.observeField("wasClosed", "onExitClosed")
    m.exitDialog = dialog
    m.top.dialog = dialog
end sub

sub onExitButton()
    if m.exitDialog = invalid then return
    if m.exitDialog.buttonSelected = 0
        m.top.exitApp = true
    else
        m.exitDialog.close = true
    end if
end sub

sub onExitClosed()
    m.exitDialog = invalid
end sub

' ------------------------------------------------------------------ listas ---

sub ShowAddListDialog()
    dialog = CreateObject("roSGNode", "KeyboardDialog")
    dialog.title = "URL da playlist M3U (http ou https)"
    dialog.buttons = ["Adicionar", "Cancelar"]
    dialog.observeField("buttonSelected", "onAddListButton")
    dialog.observeField("wasClosed", "onAddListClosed")
    m.addListDialog = dialog
    m.top.dialog = dialog
end sub

sub onAddListButton()
    if m.addListDialog = invalid then return
    if m.addListDialog.buttonSelected <> 0 then m.addListDialog.text = ""
    m.addListDialog.close = true
end sub

sub onAddListClosed()
    if m.addListDialog = invalid then return
    url = m.addListDialog.text.Trim()
    m.addListDialog = invalid
    if url = ""
        UpdateView()
        m.status.text = "Adição cancelada."
        return
    end if
    if not IsHttpUrl(url)
        UpdateView()
        m.status.text = "URL inválida. Use um endereço http:// ou https://."
        return
    end if
    if HasListUrl(m.lists, url)
        UpdateView()
        m.status.text = "Essa lista já está cadastrada."
        return
    end if
    m.lists.Push({name: "Lista personalizada " + (m.lists.Count() + 1).ToStr(), url: url, active: true})
    SaveLists()
    RefreshCatalog()
    UpdateView()
    m.status.text = "Lista adicionada. Carregando canais..."
end sub

sub RemoveFocusedList()
    if m.focusArea <> "list" then return
    idx = m.channelList.itemFocused
    if idx < 2 or idx > m.lists.Count() + 1 then return
    m.lists.Delete(idx - 2)
    SaveLists()
    BuildCatalog()
    UpdateView()
    m.status.text = "Lista removida."
end sub

' ----------------------------------------------------- favoritos / histórico ---

sub ToggleFavoriteFocused()
    if m.focusArea <> "list"
        m.status.text = "Entre na lista (→) para favoritar."
        return
    end if
    if m.listKind = "lists" or m.listKind = "update" then return
    idx = m.channelList.itemFocused
    if idx < 0 or idx >= m.viewSource.Count() then return
    ch = m.viewSource[idx]
    found = -1
    for i = 0 to m.favorites.Count() - 1
        if m.favorites[i].url = ch.url then found = i
    end for
    if found >= 0
        m.favorites.Delete(found)
        msg = "Removido dos favoritos."
    else
        m.favorites.Push(ch)
        msg = "Adicionado aos favoritos."
    end if
    SaveData("favorites", m.favorites)
    UpdateView()
    m.status.text = msg
end sub

sub AddHistory(ch as Object)
    for i = m.history.Count() - 1 to 0 step -1
        if m.history[i].url = ch.url then m.history.Delete(i)
    end for
    m.history.Unshift(ch)
    while m.history.Count() > 25
        m.history.Delete(m.history.Count() - 1)
    end while
    SaveData("history", m.history)
end sub

' ------------------------------------------------------------------- busca ---

sub ShowSearchDialog()
    if m.channels.Count() = 0
        m.status.text = "Aguarde o carregamento dos canais antes de buscar."
        return
    end if
    dialog = CreateObject("roSGNode", "KeyboardDialog")
    dialog.title = "Buscar canal"
    dialog.buttons = ["Buscar", "Cancelar"]
    dialog.observeField("buttonSelected", "onSearchButton")
    dialog.observeField("wasClosed", "onSearchClosed")
    m.searchDialog = dialog
    m.top.dialog = dialog
end sub

sub onSearchButton()
    if m.searchDialog = invalid then return
    if m.searchDialog.buttonSelected <> 0 then m.searchDialog.text = ""
    m.searchDialog.close = true
end sub

sub onSearchClosed()
    if m.searchDialog = invalid then return
    query = LCase(m.searchDialog.text.Trim())
    m.searchDialog = invalid
    if query = ""
        UpdateView()
        m.status.text = "Busca cancelada."
        return
    end if
    m.visibleChannels = []
    for each ch in m.channels
        if Instr(1, LCase(ch.name), query) > 0 then m.visibleChannels.Push(ch)
    end for
    m.currentView = "search"
    m.sectionTitle.text = "Resultados da busca"
    m.focusArea = "list"
    UpdateView()
    m.status.text = m.visibleChannels.Count().ToStr() + " resultado(s) para: " + query
end sub

' ------------------------------------------------------------- persistência ---

sub LoadSavedData()
    m.lists = LoadData("lists", [])
    m.favorites = LoadData("favorites", [])
    m.history = LoadData("history", [])
end sub

function LoadAny(key as String, fallback as Dynamic) as Dynamic
    sec = CreateObject("roRegistrySection", "RPIPTV")
    if not sec.Exists(key) then return fallback
    obj = ParseJson(sec.Read(key))
    if obj = invalid then return fallback
    return obj
end function

function LoadData(key as String, fallback as Dynamic) as Dynamic
    obj = LoadAny(key, fallback)
    if type(obj) <> "roArray" then return fallback
    return obj
end function

sub SaveData(key as String, value as Dynamic)
    json = FormatJson(value)
    if json = invalid then return
    sec = CreateObject("roRegistrySection", "RPIPTV")
    sec.Write(key, json)
    sec.Flush()
end sub

sub SaveLists()
    SaveData("lists", m.lists)
end sub

' ------------------------------------------------- pareamento pelo celular ---
' Fluxo: cria um código no Supabase, mostra QR + código, consulta a cada 4 s.
' Quando o celular envia a URL, o banco a entrega uma vez e a lista é adicionada.

sub StartPairing()
    if m.pairState <> "" then return
    m.pairCode = RandomPairCode()
    m.pairStart = CreateObject("roDateTime").AsSeconds()
    m.pairState = "criando"
    m.pairBusy = true
    m.pairGroup.visible = true
    m.pairCodeText.text = m.pairCode
    m.pairInfo.text = "Leia o QR code com o celular, ou acesse " + PairPageUrl() + " e digite o código acima. Depois cole o endereço da lista."
    m.pairQr.uri = QrServiceUrl() + UrlEncode(PairPageUrl() + "?c=" + m.pairCode)
    m.pairStatus.text = "Gerando código..."
    SendPairRequest("criar_pareamento", {p_codigo: m.pairCode})
end sub

sub SendPairRequest(funcao as String, corpo as Object)
    task = CreateObject("roSGNode", "SupabaseTask")
    task.funcao = funcao
    task.corpo = FormatJson(corpo)
    task.observeField("codigoHttp", "onPairResponse")
    m.pairTask = task
    m.top.appendChild(task)
    task.control = "RUN"
end sub

sub onPairResponse()
    if m.pairTask = invalid then return
    tarefa = m.pairTask
    codigo = tarefa.codigoHttp
    texto = tarefa.resposta
    tarefa.unobserveField("codigoHttp")
    m.top.removeChild(tarefa)
    m.pairTask = invalid
    m.pairBusy = false
    ok = (codigo >= 200 and codigo < 300)

    if m.pairState = "criando"
        if ok
            m.pairState = "aguardando"
            m.pairStatus.text = "Aguardando o envio pelo celular..."
            m.pairTimer.control = "start"
        else
            EndPairing("Sem conexão com o serviço de pareamento. Use 'Digitar a URL' na lista de listas.")
        end if
    else if m.pairState = "aguardando"
        if ok and texto <> ""
            r = ParseJson(texto)
            if r <> invalid
                if r.status = "ok"
                    ReceivedPairUrl(r.url)
                else if r.status = "expirado"
                    EndPairing("O código expirou. Tente de novo.")
                end if
            end if
        end if
    end if
end sub

sub onPairTimer()
    now = CreateObject("roDateTime").AsSeconds()
    if m.pairState = "aguardando"
        if now - m.pairStart > 600
            EndPairing("O código expirou. Tente de novo.")
            return
        end if
        if not m.pairBusy
            m.pairBusy = true
            SendPairRequest("retirar_url", {p_codigo: m.pairCode})
        end if
    else if m.pairState = "criando"
        if now - m.pairStart > 20
            EndPairing("Sem resposta do serviço de pareamento. Use 'Digitar a URL' na lista de listas.")
        end if
    end if
end sub

sub ReceivedPairUrl(url as String)
    if not IsHttpUrl(url)
        EndPairing("O celular enviou um endereço inválido.")
        return
    end if
    if HasListUrl(m.lists, url)
        EndPairing("Essa lista já estava cadastrada.")
        return
    end if
    m.lists.Push({name: "Lista do celular " + (m.lists.Count() + 1).ToStr(), url: url, active: true})
    SaveLists()
    EndPairing("Lista recebida do celular e adicionada.")
    RefreshCatalog()
end sub

sub EndPairing(msg as String)
    m.pairTimer.control = "stop"
    if m.pairTask <> invalid
        m.pairTask.unobserveField("codigoHttp")
        m.top.removeChild(m.pairTask)
    end if
    m.pairTask = invalid
    m.pairState = ""
    m.pairBusy = false
    m.pairGroup.visible = false
    m.pairQr.uri = ""
    m.focusArea = "list"
    UpdateView()
    m.status.text = msg
end sub

sub CancelPairing()
    EndPairing("Pareamento cancelado.")
end sub

' ------------------------------------------------------------- atualização ---
' O Roku não permite trocar o código de um app em execução pela internet. Aqui o app verifica
' e avisa; a instalação é feita como na primeira vez (Developer Application Installer).

function AutoCheckOn() as Boolean
    return LoadAny("autoCheck", true) <> false
end function

function UpdateItems() as Object
    itens = [{label: "Versão instalada: " + LocalVersion(), action: "info"}]
    if m.updateRemote <> invalid
        itens.Push({label: "Nova versão disponível: " + m.updateRemote.version, action: "info"})
    end if
    if m.updateChecking
        itens.Push({label: "Verificando...", action: "none"})
    else
        itens.Push({label: "Verificar atualização agora", action: "check"})
    end if
    if m.updateRemote <> invalid
        itens.Push({label: "Como atualizar (versão " + m.updateRemote.version + ")", action: "howto"})
    end if
    estado = "NÃO"
    if AutoCheckOn() then estado = "SIM"
    itens.Push({label: "Verificar ao abrir o app: " + estado, action: "toggle"})
    return itens
end function

sub RenderUpdateList()
    m.listKind = "update"
    m.viewSource = UpdateItems()
    m.listSource = m.viewSource
    rows = CreateObject("roSGNode", "ContentNode")
    for each item in m.viewSource
        r = rows.createChild("ContentNode")
        r.title = item.label
    end for
    m.channelList.content = rows
    m.channelList.visible = true
    if m.focusArea = "list"
        m.channelList.setFocus(true)
    else
        m.menuList.setFocus(true)
    end if
    m.status.text = StatusFor()
end sub

sub RunUpdateItem(idx as Integer)
    if idx < 0 or idx >= m.viewSource.Count() then return
    acao = m.viewSource[idx].action
    if acao = "check" then CheckUpdate(false)
    if acao = "howto" then ShowHowToDialog()
    if acao = "toggle" then ToggleAutoCheck()
end sub

sub CheckUpdate(silencioso as Boolean)
    if m.updateChecking then return
    m.updateChecking = true
    m.updateSilent = silencioso
    if not silencioso then m.updateMsg = "Verificando..."
    if m.currentView = "update" and m.mode = "browse" then RenderUpdateList()
    tarefa = CreateObject("roSGNode", "UpdateTask")
    agora = CreateObject("roDateTime").AsSeconds()
    tarefa.url = UpdateVersionUrl() + "?t=" + agora.ToStr()
    tarefa.observeField("codigoHttp", "onUpdateResponse")
    m.updateTask = tarefa
    m.top.appendChild(tarefa)
    tarefa.control = "RUN"
end sub

sub onUpdateResponse()
    if m.updateTask = invalid then return
    tarefa = m.updateTask
    codigo = tarefa.codigoHttp
    texto = tarefa.resposta
    tarefa.unobserveField("codigoHttp")
    m.top.removeChild(tarefa)
    m.updateTask = invalid
    m.updateChecking = false
    m.updateRemote = invalid
    if codigo >= 200 and codigo < 300 and texto <> ""
        info = ParseJson(texto)
        if type(info) = "roAssociativeArray" and info.version <> invalid
            if CompareVersion(info.version, LocalVersion()) > 0
                m.updateRemote = info
                m.updateMsg = "Nova versão " + info.version + " disponível. Veja Como atualizar."
            else
                m.updateMsg = "Você já está na versão mais recente."
            end if
        else
            m.updateMsg = "Arquivo de versão inválido."
        end if
    else
        m.updateMsg = "Não foi possível verificar. Confira a conexão com a internet."
    end if
    if m.currentView = "update" and m.mode = "browse"
        RenderUpdateList()
    else if m.updateSilent and m.updateRemote <> invalid
        m.status.text = "Nova versão " + m.updateRemote.version + " disponível. Veja em Atualização."
    end if
end sub

sub ShowHowToDialog()
    if m.infoDialog <> invalid then return
    if m.updateRemote = invalid then return
    dialog = CreateObject("roSGNode", "StandardMessageDialog")
    dialog.title = "Como atualizar"
    dialog.message = [
        "1. Baixe o arquivo da versão " + m.updateRemote.version + " no celular ou no computador:",
        m.updateRemote.url,
        "2. Instale pelo Developer Application Installer, do mesmo jeito da primeira instalação.",
        "3. Ao abrir, confira se suas listas e favoritos continuam aparecendo."
    ]
    dialog.buttons = ["OK"]
    dialog.observeField("buttonSelected", "onInfoButton")
    dialog.observeField("wasClosed", "onInfoClosed")
    m.infoDialog = dialog
    m.top.dialog = dialog
end sub

sub onInfoButton()
    if m.infoDialog <> invalid then m.infoDialog.close = true
end sub

sub onInfoClosed()
    m.infoDialog = invalid
end sub

sub ToggleAutoCheck()
    if AutoCheckOn()
        SaveData("autoCheck", false)
        m.updateMsg = "Verificação ao abrir desligada."
    else
        SaveData("autoCheck", true)
        m.updateMsg = "Verificação ao abrir ligada."
    end if
    RenderUpdateList()
end sub
