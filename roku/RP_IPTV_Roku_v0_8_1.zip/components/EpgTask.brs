sub init()
    m.top.functionName = "Run"
end sub

sub Run()
    url = m.top.url
    if url = invalid or url = ""
        m.top.error = "URL vazia"
        return
    end if
    xfer = CreateObject("roUrlTransfer")
    xfer.SetUrl(url)
    xfer.AddHeader("User-Agent", "RP-IPTV-Roku/0.5")
    xfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.InitClientCertificates()
    xmlText = xfer.GetToString()
    if xmlText = invalid or xmlText = ""
        m.top.error = "Download XMLTV falhou"
        return
    end if
    m.top.result = ParseXmltvText(xmlText)
end sub
