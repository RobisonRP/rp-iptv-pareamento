' Chama uma função RPC do Supabase (POST /rest/v1/rpc/<funcao>) em segundo plano.
' Resultado: resposta (texto) e codigoHttp: 200 quando a chamada respondeu sem erro, 0 se falhou.
' codigoHttp é definido por último, porque é ele que dispara o observador na tela.
' (GetResponseCode() não é válido para roUrlTransfer síncrono: causava travamento.)

sub init()
    m.top.functionName = "Run"
end sub

sub Run()
    xfer = CreateObject("roUrlTransfer")
    xfer.SetUrl(SupabaseUrl() + "/rest/v1/rpc/" + m.top.funcao)
    xfer.AddHeader("apikey", SupabaseKey())
    xfer.AddHeader("Authorization", "Bearer " + SupabaseKey())
    xfer.AddHeader("Content-Type", "application/json")
    xfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.InitClientCertificates()
    texto = xfer.PostFromString(m.top.corpo)
    if texto = invalid then texto = ""
    texto = texto.Trim()
    m.top.resposta = texto
    codigo = 0
    if texto <> "" or m.top.funcao = "criar_pareamento" then codigo = 200
    if Left(texto, 1) = "{" or Left(texto, 1) = "[" or Left(texto, 1) = Chr(34) then codigo = 200
    m.top.codigoHttp = codigo
end sub
