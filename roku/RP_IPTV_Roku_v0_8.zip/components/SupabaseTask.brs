' Chama uma função RPC do Supabase (POST /rest/v1/rpc/<funcao>) em segundo plano.
' Resultado: resposta (texto JSON) e codigoHttp. codigoHttp é definido por último,
' porque é ele que dispara o observador na tela.

sub init()
    m.top.functionName = "Run"
end sub

sub Run()
    xfer = CreateObject("roUrlTransfer")
    xfer.SetUrl(SupabaseUrl() + "/rest/v1/rpc/" + m.top.funcao)
    xfer.AddHeader("apikey", SupabaseKey())
    xfer.AddHeader("Authorization", "Bearer " + SupabaseKey())
    xfer.AddHeader("Content-Type", "application/json")
    xfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.InitClientCertificates()
    texto = xfer.PostFromString(m.top.corpo)
    if texto = invalid then texto = ""
    m.top.resposta = texto
    m.top.codigoHttp = xfer.GetResponseCode()
end sub
