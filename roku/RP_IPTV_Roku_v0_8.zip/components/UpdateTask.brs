' Baixa o arquivo de versão do GitHub em segundo plano.
' codigoHttp é definido por último, porque é ele que dispara o observador na tela.

sub init()
    m.top.functionName = "Run"
end sub

sub Run()
    xfer = CreateObject("roUrlTransfer")
    xfer.SetUrl(m.top.url)
    xfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.InitClientCertificates()
    texto = xfer.GetToString()
    if texto = invalid then texto = ""
    m.top.resposta = texto
    m.top.codigoHttp = xfer.GetResponseCode()
end sub
